package com.jcodecraeer.xrecyclerview;

public interface ItemTouchHelperAdapter {
    void onItemDismiss(int i);

    void onItemMove(int i, int i2);
}
