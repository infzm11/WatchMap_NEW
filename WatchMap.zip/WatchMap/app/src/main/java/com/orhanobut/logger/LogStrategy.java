package com.orhanobut.logger;

public interface LogStrategy {
    void log(int i, String str, String str2);
}
