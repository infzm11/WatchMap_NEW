package com.orhanobut.logger;

public interface FormatStrategy {
    void log(int i, String str, String str2);
}
