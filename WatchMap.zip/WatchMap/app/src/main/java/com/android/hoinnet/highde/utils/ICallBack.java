package com.android.hoinnet.highde.utils;

public interface ICallBack {
    void onCompleted(int i);
}
